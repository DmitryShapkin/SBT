//
//  DSViewController.m
//  SBT-Lesson-21 SberPoisk
//
//  Created by Dmitry Shapkin on 19/04/2019.
//  Copyright © 2019 Dmitry Shapkin. All rights reserved.
//


#import "DSViewController.h"
#import "DSDataSource.h"
#import "DSPhotoCollectionViewCell.h"
#import "DSImageViewController.h"
#import "SberColor.h"


static const CGFloat kMargin = 10;

@interface DSViewController () <UITextFieldDelegate, UISearchBarDelegate, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, CollectionViewItemDelegate>

@property (nonatomic, strong) UITextField *searchBox;
@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) UISearchBar *searchBar;
@property (nonatomic, strong) DSDataSource *flickrDataSource;
//@property (nonatomic, weak) id<CollectionViewItemDelegate> delegate;



@end


@implementation DSViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [SberColor darkGreenSberColor];
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
//
//    self.navigationController.navigationBar.backgroundColor = [UIColor blackColor];

//    self.navigationController.navigationBar.translucent = NO;
//    [self.navigationController setNavigationBarHidden:YES];
//    self.navigationController.view.backgroundColor = [UIColor blackColor];
    
    
    
    // Logo
    
    UIImage *logo = [UIImage imageNamed:@"logoSber"];
    UIImageView *titleImageView = [[UIImageView alloc] initWithImage:logo] ;
    self.navigationItem.titleView = titleImageView;
    
    

    
    //Отступ сверху для навигейшн бара
    CGFloat topInset = CGRectGetMaxY(self.navigationController.navigationBar.frame);
    CGFloat screenWidth = UIScreen.mainScreen.bounds.size.width;
    
    //Инициализация серч бара
    CGFloat searchBarHeight = 50;
    self.searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, screenWidth, searchBarHeight)];
    [self.searchBar setPlaceholder:@"Введите запрос"];
    self.searchBar.barTintColor = [SberColor darkGreenSberColor];
    self.searchBar.layer.borderColor = [SberColor darkGreenSberColor].CGColor;
    self.searchBar.layer.borderWidth = 1;
//    self.searchBar.layer.cornerRadius = 20;
    
    self.searchBar.delegate = self;
    [self.view addSubview:self.searchBar];
    
    
    
    
    
    
    
    
    

    
    
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.sectionInset = UIEdgeInsetsMake(15, 15, 15, 15);
    
    
    // CollectionView
    
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
    
    [_collectionView registerClass:[DSPhotoCollectionViewCell class]
        forCellWithReuseIdentifier:DSCellIdentifier];
    _flickrDataSource = [[DSDataSource alloc] initWithWidth:screenWidth];
    _flickrDataSource.collectionView = _collectionView;
    _flickrDataSource.delegate = self;
    _collectionView.dataSource = _flickrDataSource;
    _collectionView.delegate = _flickrDataSource;
    [_collectionView setBackgroundColor:[UIColor whiteColor]];
    
    [self.view addSubview:_collectionView];
    _collectionView.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
          [_collectionView.topAnchor constraintEqualToAnchor:self.searchBar.bottomAnchor],
          [_collectionView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
          [_collectionView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
          [_collectionView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor]
    ]];
}

- (void)startSearch {
    if ([self checkEnglishLetters])
    {
        [_flickrDataSource showPicturesWithQuery:self.searchBar.text];
        [_searchBar endEditing:YES];
    }
    else
    {
        [self showAlertWithTitle:@"Запрос не может быть обработан" message:@"По-русски писать нельзя. Пожалуйста, используйте английскую раскладку"];
    }
}

- (void)showAlertWithTitle:(NSString *)title message:(NSString *)message
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *alertAction = [UIAlertAction actionWithTitle:@"Ок" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [alertController dismissViewControllerAnimated:true completion:nil];
    }];
    [alertController addAction:alertAction];
    [self presentViewController:alertController animated:true completion:nil];
}

/** Проверка на английские буквы */
- (BOOL)checkEnglishLetters
{
    NSCharacterSet *englishLettersAndNumbers = [NSCharacterSet characterSetWithCharactersInString: @"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"];
    NSCharacterSet *notLetters = [englishLettersAndNumbers invertedSet];
    NSRange range = [self.searchBar.text rangeOfCharacterFromSet:notLetters];
    return range.location == NSNotFound ? YES : NO;
}

- (UIEdgeInsets)safeAreaInsets {
    static CGFloat kStatusBarHeight = 20;
    
    /** Решение с отступом от SafeArea */
    if (@available(iOS 11.0, *)) {
        UIWindow *window = nil;
        id appDelegate = UIApplication.sharedApplication.delegate;
        if ([appDelegate respondsToSelector:@selector(window)]) {
            window = [appDelegate window];
        } else {
            window = UIApplication.sharedApplication.keyWindow;
        }
        UIEdgeInsets safeAreaInsets = window.safeAreaInsets;
        CGFloat top = MAX(safeAreaInsets.top, kStatusBarHeight);
        return UIEdgeInsetsMake(top, safeAreaInsets.right, safeAreaInsets.bottom, safeAreaInsets.left);
    }
    
    return UIEdgeInsetsMake(kStatusBarHeight, 0, 0, 0);
}


#pragma mark - UISearchBarDelegate

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [self startSearch];
}


#pragma mark - CollectionViewItemDelegate

- (void)pushViewControllerWithImageUrl:(NSString *)url
{
    DSImageViewController *imageViewController = [DSImageViewController new];
    imageViewController.imageURL = url;
    [self.navigationController pushViewController:imageViewController animated:YES];
}

@end
